import java.io.File;

import acsse.csc2a.nova.file.CelestialBodyFileReader;
import acsse.csc2a.nova.models.SolarSystem;


/**
 * Represents the interaction with the classes
 * @author Mr. Orfao
 * @version P03
 */
public class Main {

	public static void main(String[] args) {
	
		SolarSystem sol = CelestialBodyFileReader.readSolarSystemFile(new File("data/heliocentric_system.txt"));
		System.out.println(sol);
		Tester.test();
	}

}

package acsse.csc2a.nova.models;

/**
 * Represents a celestial body within a solar system.
 * <p>
 * Each celestial body has a name, a colour, and a radius. Optionally, it can have a parent celestial body.
 * The name provided may include square brackets, which are removed during construction.
 * </p>
 * 
 * @author Mr. Orfao
 * @version P03
 */
public class CelestialBody {
    private String name;
    private EColour colour;
    private int radius;
    private CelestialBody parent;

    /**
     * Constructs a {@code CelestialBody} with the specified name, radius, colour, and parent.
     * <p>
     * If the provided name contains square brackets, they are removed before storing.
     * </p>
     *
     * @param name   the name of the celestial body (may include square brackets which are removed)
     * @param radius the radius of the celestial body
     * @param colour the colour of the celestial body
     * @param parent the parent celestial body; may be {@code null} if none exists
     */
    public CelestialBody(String name, int radius, EColour colour, CelestialBody parent) {
        // Remove the brackets from the name
        name = name.replace("[", "");
        name = name.replace("]", "");
        this.name = name;
        this.colour = colour;
        this.radius = radius;
        this.parent = parent;
    }
    
    /**
     * Constructs a {@code CelestialBody} with the specified name, radius, and colour.
     * <p>
     * This constructor assumes that the celestial body has no parent.
     * </p>
     *
     * @param name   the name of the celestial body (may include square brackets which are removed)
     * @param radius the radius of the celestial body
     * @param colour the colour of the celestial body
     */
    public CelestialBody(String name, int radius, EColour colour) {
        this(name, radius, colour, null);
    }

    /**
     * Returns the name of the celestial body.
     *
     * @return the celestial body's name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the celestial body.
     *
     * @param name the new name of the celestial body
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the colour of the celestial body.
     *
     * @return the celestial body's colour
     */
    public EColour getColour() {
        return colour;
    }

    /**
     * Sets the colour of the celestial body.
     *
     * @param colour the new colour of the celestial body
     */
    public void setColour(EColour colour) {
        this.colour = colour;
    }

    /**
     * Returns the parent celestial body.
     *
     * @return the parent celestial body, or {@code null} if none exists
     */
    public CelestialBody getParent() {
        return parent;
    }

    /**
     * Sets the parent celestial body.
     *
     * @param parent the celestial body to set as the parent
     */
    public void setParent(CelestialBody parent) {
        this.parent = parent;
    }
    
    /**
     * Returns the radius of the CelestialBody.
     *
     * @return the radius of the CelestialBody.
     */
    public int getRadius() {
        return radius;
    }

    /**
     * Sets the radius of the CelestialBody.
     *
     * @param radius the radius of the CelestialBody.
     */
    public void setRadius(int radius) {
        this.radius = radius;
    }

}

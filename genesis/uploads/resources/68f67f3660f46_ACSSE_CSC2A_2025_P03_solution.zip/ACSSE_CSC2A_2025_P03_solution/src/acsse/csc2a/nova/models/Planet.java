package acsse.csc2a.nova.models;

/**
 * Represents a Planet, which is a type of celestial body.
 * <p>
 * A Planet has an additional attribute called habitability,
 * which represents a floating-point value indicating its habitability index.
 * </p>
 * 
 * @author Mr. Orfao
 * @version P03
 */
public class Planet extends CelestialBody {

    /** The habitability index of the planet. */
    private float habitable;
    
    /**
     * Constructs a Planet with the specified attributes.
     *
     * @param name      the name of the planet (may include square brackets, which are removed)
     * @param radius    the radius of the planet
     * @param colour    the colour of the planet as defined by {@link EColour}
     * @param parent    the parent celestial body of the planet
     * @param habitable the habitability index (float) of the planet
     */
    public Planet(String name, int radius, EColour colour, CelestialBody parent, float habitable) {
        super(name, radius, colour, parent);
        this.habitable = habitable;
    }
    
    
    /**
     * Retrieves the habitability index of the planet.
     *
     * @return the habitability index as a float
     */
    public float getHabitable() {
        return habitable;
    }
    
    /**
     * Sets the habitability index of the planet.
     *
     * @param habitable the new habitability index to set
     */
    public void setHabitable(float habitable) {
        this.habitable = habitable;
    }
}

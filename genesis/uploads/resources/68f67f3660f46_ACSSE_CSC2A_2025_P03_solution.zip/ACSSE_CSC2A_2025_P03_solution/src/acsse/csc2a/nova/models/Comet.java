package acsse.csc2a.nova.models;

/**
 * Represents a comet, which is a type of celestial body characterized by its radiation attribute.
 * <p>
 * A {@code Comet} extends {@link CelestialBody} and includes a unique radiation property.
 * The radiation is typically represented as a lowercase string.
 * </p>
 * 
 * @author Mr. Orfao
 * @version P03
 */
public class Comet extends CelestialBody {

    /** The radiation attribute of the comet. */
    private String radiation;
    
    /**
     * Constructs a {@code Comet} with the specified name, radius, colour, parent celestial body, and radiation.
     * <p>
     * The name may include square brackets, which are removed by the superclass constructor.
     * </p>
     *
     * @param name      the name of the comet
     * @param radius    the radius of the comet
     * @param colour    the colour of the comet, represented by an {@link EColour}
     * @param parent    the parent celestial body of the comet, or {@code null} if none exists
     * @param radiation the radiation attribute of the comet (should be a lowercase string)
     */
    public Comet(String name, int radius, EColour colour, CelestialBody parent, String radiation) {
        super(name, radius, colour, parent);
        this.radiation = radiation;
    }
    
    
    /**
     * Retrieves the radiation attribute of the comet.
     *
     * @return the radiation attribute as a {@code String}
     */
    public String getRadiation() {
        return radiation;
    }
    
    /**
     * Sets the radiation attribute of the comet.
     *
     * @param radiation the new radiation attribute to set
     */
    public void setRadiation(String radiation) {
        this.radiation = radiation;
    }
}

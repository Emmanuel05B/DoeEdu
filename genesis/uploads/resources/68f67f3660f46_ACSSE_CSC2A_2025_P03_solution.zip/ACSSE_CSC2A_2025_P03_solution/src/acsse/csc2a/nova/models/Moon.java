package acsse.csc2a.nova.models;

/**
 * Represents a Moon, which is a type of celestial body.
 * <p>
 * A Moon has an additional attribute representing its metal composition.
 * The allowed metal values are defined in the nested {@code MoonMetal} enum.
 * </p>
 * 
 * @author Mr. Orfao
 * @version P03
 */
public class Moon extends CelestialBody {

    /**
     * Enum representing the metal types for a Moon.
     */
    public enum MoonMetal {
        IRON, NICKEL, LEAD;
    }
    
    /** The metal composition of the Moon. */
    private MoonMetal metal;
    
    /**
     * Constructs a Moon with the specified attributes.
     *
     * @param name   the name of the Moon (may include square brackets, which are removed)
     * @param radius the radius of the Moon
     * @param colour the colour of the Moon as defined by {@link EColour}
     * @param parent the parent celestial body of the Moon
     * @param metal  the metal composition of the Moon
     */
    public Moon(String name, int radius, EColour colour, CelestialBody parent, MoonMetal metal) {
        super(name, radius, colour, parent);
        this.metal = metal;
    }
    
    
    /**
     * Retrieves the metal composition of the Moon.
     *
     * @return the metal composition as a {@code MoonMetal}
     */
    public MoonMetal getMetal() {
        return metal;
    }
    
    /**
     * Sets the metal composition of the Moon.
     *
     * @param metal the new metal composition to set
     */
    public void setMetal(MoonMetal metal) {
        this.metal = metal;
    }
}

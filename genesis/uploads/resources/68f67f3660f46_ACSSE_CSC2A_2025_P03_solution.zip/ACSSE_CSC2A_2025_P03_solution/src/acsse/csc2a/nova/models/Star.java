package acsse.csc2a.nova.models;

/**
 * Represents a Star, which is a type of celestial body with an age attribute.
 * <p>
 * A {@code Star} extends {@link CelestialBody} and includes an additional attribute, {@code age},
 * which represents the star's age.
 * </p>
 * 
 * @author Mr. Orfao
 * @version P02
 */
public class Star extends CelestialBody {
    
    /** The age of the star. */
    private int age;
    
    /**
     * Constructs a Star with the specified attributes.
     *
     * @param name   the name of the star (may include square brackets, which are removed)
     * @param radius the radius of the star
     * @param colour the colour of the star as defined by {@link EColour}
     * @param parent the parent celestial body of the star
     * @param age    the age of the star as an integer
     */
    public Star(String name, int radius, EColour colour, CelestialBody parent, int age) {
        super(name, radius, colour, parent);
        this.age = age;
    }
    
    
    /**
     * Retrieves the age of the star.
     *
     * @return the age of the star as an integer
     */
    public int getAge() {
        return age;
    }
    
    /**
     * Sets the age of the star.
     *
     * @param age the new age to set for the star
     */
    public void setAge(int age) {
        this.age = age;
    }
}
